﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace binding091
{
    public partial class Form1 : Form
    {
        private DataTable dt;
        public Form1()
        {
            InitializeComponent();
            InitializeDataTable();
        }
        private void InitializeDataTable()
        {
            // Step 1: Creating a DataTable.
            dt = new DataTable();

            // Step 2: Creating columns with their data types.
            DataColumn dc1 = new DataColumn("PERSONAL NO", typeof(int));
            DataColumn dc2 = new DataColumn("NAME", typeof(string));
            DataColumn dc3 = new DataColumn("DATE", typeof(string)); // You can also use DateTime
            DataColumn dc4 = new DataColumn("QUANTITY", typeof(int));
            DataColumn dc5 = new DataColumn("TYPE", typeof(string));

            // Step 3: Adding these Columns to the DataTable.
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.Columns.Add(dc4);
            dt.Columns.Add(dc5);
        }
        
    private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add( "21011556-086", "Maida Zafar", DateTime.Now.ToShortDateString(), "10", "Type A");
            dataGridView1.Rows.Add( "21011556-128", "Affaf Shahid", DateTime.Now.ToShortDateString(), "20", "Type B");
           dataGridView1.Rows.Add("21011556-127", "Hina Muzaffar", DateTime.Now.ToShortDateString(), "20", "Type B");
            dataGridView1.Rows.Add("21011556-098", "Muqadas", DateTime.Now.ToShortDateString(), "10", "Type A");

        }
                
    

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
    }
    private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
